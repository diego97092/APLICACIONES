const DEFAULTS = {
  enabled: false,
  autostartDelayMs: 5000,
  backendBase: 'http://127.0.0.1:8000',
  perfilId: 1,
  lastStatus: 'Instalada. Interruptor apagado.'
};

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.local.get(Object.keys(DEFAULTS));
  await chrome.storage.local.set({ ...DEFAULTS, ...current });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg?.type === 'MH_GET_STATE') {
      const state = await chrome.storage.local.get(Object.keys(DEFAULTS).concat(['running','lastStatus','lastError','lastSync']));
      sendResponse({ ok: true, state: { ...DEFAULTS, ...state } });
      return;
    }
    if (msg?.type === 'MH_SET_ENABLED') {
      await chrome.storage.local.set({ enabled: !!msg.enabled, lastStatus: msg.enabled ? 'Encendida. Esperando 5 segundos para arrancar.' : 'Apagada por el usuario.', running: false });
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: 'MH_STATE_CHANGED', enabled: !!msg.enabled }).catch(()=>{});
      sendResponse({ ok: true });
      return;
    }
    if (msg?.type === 'MH_RUN_NOW') {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id) await chrome.tabs.sendMessage(tab.id, { type: 'MH_RUN_NOW' });
      sendResponse({ ok: true });
      return;
    }
    if (msg?.type === 'MH_STATUS') {
      await chrome.storage.local.set({ lastStatus: msg.status || '', lastError: msg.error || '', lastSync: Date.now(), running: !!msg.running });
      sendResponse({ ok: true });
      return;
    }
  })();
  return true;
});
