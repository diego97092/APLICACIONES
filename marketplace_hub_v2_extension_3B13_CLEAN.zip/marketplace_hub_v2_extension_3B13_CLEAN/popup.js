const $ = id => document.getElementById(id);
let enabled=false;
async function getState(){return await chrome.runtime.sendMessage({type:'MH_GET_STATE'});}
async function refresh(){
 const r=await getState(); const s=r.state||{}; enabled=!!s.enabled;
 $('toggle').textContent=enabled?'EXTENSIÓN ENCENDIDA - apagar':'EXTENSIÓN APAGADA - encender';
 $('toggle').className=enabled?'off':'on';
 $('backend').value=s.backendBase||'http://127.0.0.1:8000'; $('perfil').value=s.perfilId||1;
 $('status').textContent=(s.lastStatus||'')+(s.lastError?'\nERROR: '+s.lastError:'');
}
async function save(){await chrome.storage.local.set({backendBase:$('backend').value.trim(), perfilId:Number($('perfil').value)||1});}
$('toggle').onclick=async()=>{await save(); await chrome.runtime.sendMessage({type:'MH_SET_ENABLED',enabled:!enabled}); setTimeout(refresh,300);};
$('run').onclick=async()=>{await save(); await chrome.runtime.sendMessage({type:'MH_RUN_NOW'}); $('status').textContent='Orden enviada.';};
$('bandeja').onclick=async()=>{await save(); const [tab]=await chrome.tabs.query({active:true,currentWindow:true}); chrome.tabs.sendMessage(tab.id,{type:'MH_CAPTURE_BANDEJA'});};
$('historial').onclick=async()=>{await save(); const [tab]=await chrome.tabs.query({active:true,currentWindow:true}); chrome.tabs.sendMessage(tab.id,{type:'MH_CAPTURE_HISTORIAL'});};
refresh(); setInterval(refresh,1200);
