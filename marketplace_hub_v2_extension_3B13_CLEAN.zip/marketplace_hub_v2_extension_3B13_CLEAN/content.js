(() => {
  if (window.__MHV2_3B13__) return; window.__MHV2_3B13__ = true;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = s => (s || '').replace(/\s+/g, ' ').trim();
  const log = (...a) => { console.log('[MH 3B.13]', ...a); status(a.join(' ')); };
  const err = (...a) => { console.error('[MH 3B.13]', ...a); status(a.join(' '), true); };
  let running = false, startedOnce = false;

  async function cfg() {
    const r = await chrome.runtime.sendMessage({ type: 'MH_GET_STATE' }).catch(()=>({state:{}}));
    return r.state || {};
  }
  function status(text, isError=false) {
    chrome.runtime.sendMessage({ type:'MH_STATUS', status: String(text||''), error: isError?String(text||''):'', running }).catch(()=>{});
    updateCrmBanner(text, isError);
  }

  // Banner/botón dentro del CRM sin tocar main.py
  async function injectCrmBanner() {
    if (!location.href.startsWith('http://127.0.0.1:8000') && !location.href.startsWith('http://localhost:8000')) return;
    if (document.getElementById('mh-ext-banner')) return;
    const s = await cfg();
    const bar = document.createElement('div'); bar.id='mh-ext-banner';
    bar.style.cssText='position:fixed;right:18px;bottom:18px;z-index:999999;background:#0f172a;color:white;border:2px solid #38bdf8;border-radius:12px;padding:12px 14px;font-family:Arial;box-shadow:0 8px 25px #0005;max-width:360px';
    bar.innerHTML=`<b>Extensión Marketplace Hub</b><div id="mh-ext-state" style="font-size:13px;margin:6px 0">${s.enabled?'ENCENDIDA':'APAGADA'}</div><button id="mh-ext-on" style="background:#22c55e;border:0;border-radius:8px;padding:8px 10px;font-weight:bold;cursor:pointer">Encender</button> <button id="mh-ext-off" style="background:#ef4444;color:white;border:0;border-radius:8px;padding:8px 10px;font-weight:bold;cursor:pointer">Apagar</button> <button id="mh-ext-run" style="background:#38bdf8;border:0;border-radius:8px;padding:8px 10px;font-weight:bold;cursor:pointer">Ejecutar</button>`;
    document.body.appendChild(bar);
    document.getElementById('mh-ext-on').onclick=()=>chrome.runtime.sendMessage({type:'MH_SET_ENABLED',enabled:true});
    document.getElementById('mh-ext-off').onclick=()=>chrome.runtime.sendMessage({type:'MH_SET_ENABLED',enabled:false});
    document.getElementById('mh-ext-run').onclick=()=>chrome.runtime.sendMessage({type:'MH_RUN_NOW'});
  }
  function updateCrmBanner(text, isError) {
    const el = document.getElementById('mh-ext-state'); if (!el) return;
    el.textContent = text || ''; el.style.color = isError ? '#fca5a5' : '#bbf7d0';
  }

  function isFacebook() { return /(^|\.)facebook\.com$/.test(location.hostname.replace('www.','')) || location.hostname === 'www.facebook.com'; }
  function isMessages() { return location.pathname.startsWith('/messages'); }

  async function runFull() {
    if (running) return; running = true;
    try {
      const s = await cfg(); if (!s.enabled) { running=false; return; }
      log('Encendida. Inicio en 5 segundos...'); await sleep(Number(s.autostartDelayMs)||5000);
      if (!isFacebook()) { running=false; return; }
      if (!isMessages()) { log('Entrando a Messenger...'); location.href='https://www.facebook.com/messages'; return; }
      await waitPageReady();
      const ok = await openMarketplaceDrawerStrict();
      if (!ok) throw new Error('No logré abrir el cajón REAL de Marketplace. No capturo Messenger general.');
      const chats = captureMarketplaceInbox();
      await sync('bandeja', { perfil_id: s.perfilId || 1, chats, fuente:'extension_3B13', url: location.href });
      log(`Bandeja Marketplace capturada: ${chats.length} chats.`);
      if (chats.length) await clickFirstMarketplaceChat();
      await sleep(2500);
      const hist = captureCurrentChatHistory();
      await sync('historial', { perfil_id: s.perfilId || 1, chat: getCurrentChatInfo(), mensajes: hist, url: location.href, fuente:'extension_3B13' });
      log(`Historial capturado: ${hist.length} mensajes.`);
    } catch(e) { err(e.message || e); }
    running = false;
  }

  async function waitPageReady(){ for(let i=0;i<30;i++){ if(document.querySelector('[role="main"], a[href*="/messages/t/"]')) return true; await sleep(500);} return false; }

  function leftPane(){
    const search = Array.from(document.querySelectorAll('input, [aria-label]')).find(e => /buscar en messenger|search messenger/i.test(e.getAttribute('aria-label')||e.placeholder||''));
    let n = search; for (let i=0; n && i<6; i++, n=n.parentElement) {
      if (n && n.querySelectorAll('a[href*="/messages"]').length >= 1) return n;
    }
    const candidates = Array.from(document.querySelectorAll('div[role="navigation"], div[aria-label], div'))
      .filter(d => d.getBoundingClientRect().left < 430 && d.getBoundingClientRect().width > 240 && d.querySelectorAll('a[href*="/messages"]').length);
    return candidates.sort((a,b)=>b.querySelectorAll('a[href*="/messages"]').length-a.querySelectorAll('a[href*="/messages"]').length)[0] || document.body;
  }

  function visible(el){ const r=el.getBoundingClientRect(); return r.width>20 && r.height>15 && r.bottom>70 && r.top<innerHeight-20; }
  function getLeftPaneText() {
    return norm(leftPane().innerText || leftPane().textContent || '');
  }

  function marketplaceRows(){
    const pane = leftPane();
    return Array.from(pane.querySelectorAll('a, div[role="button"], [tabindex="0"]')).filter(el => {
      const t = norm(el.innerText || el.textContent); if (!visible(el)) return false;
      return /^Marketplace(\s|$)/i.test(t) || t === 'Marketplace';
    });
  }

  function realConversationLinks(){
    const pane = leftPane();
    const links = Array.from(pane.querySelectorAll('a[href*="/messages/t/"]')).filter(a => {
      const t = norm(a.innerText); if (!visible(a) || !t) return false;
      if (/^Marketplace(\s|$)/i.test(t)) return false;
      if (/Meta AI|Facebook Marketplace Assistant|Marketplace Assistant|Todos|No leídos|No leidos|Grupos/i.test(t)) return false;
      return true;
    });
    // orden visual real, no orden del DOM
    return links.sort((a,b)=>a.getBoundingClientRect().top-b.getBoundingClientRect().top);
  }

  function isMarketplaceDrawerActive(){
    const pane = leftPane();
    const txt = getLeftPaneText();
    const links = realConversationLinks();
    const hasFilters = /\bTodos\b|No le[ií]dos|\bGrupos\b/i.test(txt);
    const hasBackMarketplaceTitle = Array.from(pane.querySelectorAll('span, h1, h2, div'))
      .some(el => visible(el) && norm(el.textContent) === 'Marketplace' && el.getBoundingClientRect().top < 260);
    const topNames = links.slice(0,4).map(a=>norm(a.innerText).slice(0,60));
    // Cajón REAL de Marketplace: desaparecen filtros de Messenger general y aparecen links de conversación debajo del título Marketplace.
    const active = links.length >= 1 && !hasFilters && hasBackMarketplaceTitle;
    if (active) log('Ya estoy dentro del cajón Marketplace. NO vuelvo a hacer click.', JSON.stringify(topNames));
    return active;
  }

  function drawerLooksReal(){
    return isMarketplaceDrawerActive();
  }

  async function humanClick(el, label='elemento'){
    el.scrollIntoView({block:'center', inline:'center'}); await sleep(250);
    const r = el.getBoundingClientRect(); const x = r.left + Math.min(Math.max(45, r.width/2), r.width-8); const y = r.top + r.height/2;
    for (const type of ['pointerover','mouseover','pointermove','mousemove','pointerdown','mousedown','pointerup','mouseup','click']) {
      el.dispatchEvent(new MouseEvent(type, {bubbles:true, cancelable:true, clientX:x, clientY:y, view:window}));
    }
    log('Click:', label);
  }

  async function openMarketplaceDrawerStrict(){
    log('Validando cajón Marketplace real...');
    await sleep(700);
    if (isMarketplaceDrawerActive()) return true;

    for (let attempt=1; attempt<=4; attempt++) {
      if (isMarketplaceDrawerActive()) return true;
      const rows = marketplaceRows();
      log(`Intento ${attempt}: filas Marketplace detectadas ${rows.length}`);
      if (!rows.length) { await sleep(1200); continue; }

      // Solo hacemos UN click por intento. Si entra, paramos. Nunca clicamos Marketplace otra vez si ya abrió el cajón.
      const row = rows[0];
      const textNode = Array.from(row.querySelectorAll('span, div'))
        .find(x => visible(x) && norm(x.textContent)==='Marketplace') || row;
      await humanClick(textNode, 'abrir cajón Marketplace');

      for (let j=0; j<8; j++) {
        await sleep(650);
        if (isMarketplaceDrawerActive()) return true;
      }
    }

    const current = realConversationLinks().map(a=>norm(a.innerText).slice(0,60));
    log('No capturo porque no pude validar el cajón Marketplace real:', JSON.stringify(current));
    return false;
  }


  function findScrollBox(){
    const pane = leftPane();
    const candidates = [pane, ...Array.from(pane.querySelectorAll('div'))].filter(el => {
      const r = el.getBoundingClientRect();
      return visible(el) && r.left < 430 && r.width > 180 && el.scrollHeight > el.clientHeight + 80;
    });
    return candidates.sort((a,b)=>(b.scrollHeight-b.clientHeight)-(a.scrollHeight-a.clientHeight))[0] || pane;
  }

  function chatMatchesAction(a, action){
    const txt = norm(a.innerText || '').toLowerCase();
    const href = a.href || '';
    if (action.facebook_chat_id && href.includes('/messages/t/' + action.facebook_chat_id)) return true;
    if (action.enlace_chat) {
      const id = (action.enlace_chat.match(/\/messages\/t\/([^/?#]+)/)||[])[1] || '';
      if (id && href.includes('/messages/t/' + id)) return true;
    }
    if (action.cliente) {
      const target = norm(action.cliente).toLowerCase();
      if (target && (txt.startsWith(target) || txt.includes(target + ' ·') || txt.includes(target + ' '))) return true;
    }
    return false;
  }

  async function findConversationWithScroll(action, maxSteps=22){
    if (!drawerLooksReal()) throw new Error('No estoy en cajón Marketplace real para buscar con scroll.');
    const box = findScrollBox();
    const original = box.scrollTop;
    const seenPositions = new Set();

    async function scanHere(label){
      const links = realConversationLinks();
      const found = links.find(a => chatMatchesAction(a, action));
      if (found) {
        log('Chat encontrado con scroll:', label, norm(found.innerText).slice(0,90));
        return found;
      }
      return null;
    }

    let found = await scanHere('posición actual');
    if (found) return found;

    // Primero buscamos hacia arriba por si el usuario venía de un chat abajo y luego seleccionó uno de arriba.
    for (let i=0; i<maxSteps; i++) {
      const before = box.scrollTop;
      box.scrollTop = Math.max(0, box.scrollTop - Math.floor(box.clientHeight * 0.82));
      await sleep(650);
      found = await scanHere('arriba ' + (i+1));
      if (found) return found;
      if (box.scrollTop === 0 || seenPositions.has(box.scrollTop)) break;
      seenPositions.add(box.scrollTop);
      if (box.scrollTop === before) break;
    }

    // Después buscamos desde arriba hacia abajo para cubrir toda la bandeja.
    box.scrollTop = 0;
    await sleep(800);
    seenPositions.clear();
    for (let i=0; i<maxSteps; i++) {
      found = await scanHere('abajo ' + (i+1));
      if (found) return found;
      const before = box.scrollTop;
      box.scrollTop = Math.min(box.scrollHeight, box.scrollTop + Math.floor(box.clientHeight * 0.82));
      await sleep(750);
      if (box.scrollTop === before || seenPositions.has(box.scrollTop)) break;
      seenPositions.add(box.scrollTop);
    }

    box.scrollTop = original;
    await sleep(300);
    return null;
  }

  async function captureInboxWithScroll(maxPages=7){
    if (!drawerLooksReal()) throw new Error('No capturo más conversaciones porque no estoy en cajón Marketplace real.');
    const box = findScrollBox();
    const byId = new Map();
    let order = 1;
    for (let page=1; page<=maxPages; page++) {
      const links = realConversationLinks();
      for (const a of links) {
        const id = (a.href.match(/\/messages\/t\/([^/?#]+)/)||[])[1] || a.href || norm(a.innerText).slice(0,80);
        if (!byId.has(id)) {
          const parsed = parseChatRowText(a.innerText || '');
          const txt = norm(a.innerText);
          const lines = norm(a.innerText).split(' · ').join('\n').split('\n').map(norm).filter(Boolean);
          const tiempo = (txt.match(/\b\d+\s*(min|h|d|sem|s|m)\b/i)||[])[0] || '';
          byId.set(id, { orden_bandeja: order++, cliente: parsed.cliente || lines[0] || `Chat ${order}`, producto: parsed.producto || 'Producto sin identificar', mensaje: lines.slice(1).join(' | '), tiempo_messenger: tiempo, enlace_chat: a.href, facebook_chat_id: (a.href.match(/\/messages\/t\/([^/?#]+)/)||[])[1] || '', texto_crudo: txt });
        }
      }
      const before = box.scrollTop;
      box.scrollTop = Math.min(box.scrollHeight, box.scrollTop + Math.floor(box.clientHeight * 0.88));
      await sleep(900);
      if (box.scrollTop === before) break;
    }
    const chats = Array.from(byId.values());
    log('Captura con scroll total:', chats.length, 'conversaciones');
    return chats;
  }

  function captureMarketplaceInbox(){
    if (!drawerLooksReal()) throw new Error('La bandeja no es Marketplace real; captura cancelada para no contaminar CRM.');
    return realConversationLinks().slice(0,10).map((a, idx) => {
      const lines = norm(a.innerText).split(' · ').join('\n').split('\n').map(norm).filter(Boolean);
      const txt = norm(a.innerText);
      const tiempo = (txt.match(/\b\d+\s*(min|h|d|sem|s|m)\b/i)||[])[0] || '';
      const parsed = parseChatRowText(a.innerText || '');
      return { orden_bandeja: idx+1, cliente: parsed.cliente || lines[0] || `Chat ${idx+1}`, producto: parsed.producto || 'Producto sin identificar', ultimo_mensaje: lines.slice(1).join(' | '), tiempo_messenger: tiempo, enlace_chat: a.href, facebook_chat_id: (a.href.match(/\/messages\/t\/([^/?#]+)/)||[])[1] || '', texto_crudo: txt };
    });
  }
  async function clickFirstMarketplaceChat(){
    if (!drawerLooksReal()) throw new Error('No abro primer chat porque no estoy en cajón Marketplace real.');
    const first = realConversationLinks()[0]; if (!first) return false;
    log('Abriendo primer chat Marketplace:', norm(first.innerText).slice(0,80));
    await humanClick(first, 'primer chat Marketplace'); return true;
  }
  function parseChatRowText(raw){
    const lines = String(raw || '').split('\n').map(norm).filter(Boolean);
    let cliente = lines[0] || '';
    cliente = cliente.replace(/^!+\s*/, '').replace(/\s+·\s+.*$/, '').trim();
    const productoLine = lines.find(x => /promo|producto|precio|cop|\$|colch[oó]n|gorra|almohada|mitsubishi|tapete|combo|exclusiva/i.test(x) && !/^t[úu]:/i.test(x));
    return { cliente: cliente || '', producto: productoLine || '' };
  }

  function getCurrentChatInfo(){
    const facebook_chat_id = (location.href.match(/\/messages\/t\/([^/?#]+)/)||[])[1] || '';
    let title = norm((document.querySelector('[role="main"] h1, [role="main"] h2')||{}).innerText) || '';

    // Facebook a veces deja document.title como "Messenger | Facebook".
    // Para no dañar el CRM, buscamos el chat seleccionado/matcheado en la bandeja izquierda.
    let fromLeft = null;
    if (facebook_chat_id) {
      const links = realConversationLinks();
      fromLeft = links.find(a => (a.href || '').includes('/messages/t/' + facebook_chat_id)) || null;
      if (fromLeft) {
        const parsed = parseChatRowText(fromLeft.innerText || '');
        if (parsed.cliente && (!title || /messenger\s*\|\s*facebook/i.test(title))) {
          title = parsed.producto ? `${parsed.cliente} · ${parsed.producto}` : parsed.cliente;
        }
      }
    }

    if (!title || /messenger\s*\|\s*facebook/i.test(title)) title = 'Cliente sin identificar';
    return { titulo: title, facebook_chat_id, enlace_chat: location.href };
  }
  function captureCurrentChatHistory(){
    const main = document.querySelector('[role="main"]') || document.body;
    const nodes = Array.from(main.querySelectorAll('[dir="auto"], div[role="row"], span')).filter(visible);
    const seen = new Set(); const out=[];
    for (const n of nodes) {
      const t = norm(n.innerText || n.textContent); if (!t || t.length<2 || seen.has(t)) continue;
      if (/Enviar una respuesta rápida|Toca una respuesta|View buyer|More options|Aa|GIF/i.test(t)) continue;
      seen.add(t); out.push({ orden_chat: out.length+1, remitente: guessSender(n), contenido: t, fecha:'', fecha_original:'', origen_hash: String(hash(t)) });
      if (out.length>=80) break;
    }
    return out;
  }
  function guessSender(n){
    const r=n.getBoundingClientRect();
    return r.left > (innerWidth * 0.55) ? 'yo' : 'cliente';
  }
  function hash(s){ let h=0; for(let i=0;i<s.length;i++) h=((h<<5)-h)+s.charCodeAt(i)|0; return h; }

  async function discoverEndpoints(kind){
    const s=await cfg(); const base=(s.backendBase||'http://127.0.0.1:8000').replace(/\/$/,'');
    const fallback = kind==='bandeja' ? ['/api/bandeja_marketplace','/api/sync_bandeja','/api/bandeja/sync','/api/conversaciones/sync_bandeja','/api/capturar_bandeja'] : ['/api/sync_historial','/api/capturar_chat','/api/chat/sync','/api/mensajes/sync','/api/conversaciones/sync_historial'];
    try {
      const j = await fetch(base+'/openapi.json').then(r=>r.ok?r.json():null);
      if (j?.paths) {
        const keys = Object.keys(j.paths).filter(p => j.paths[p].post).filter(p => kind==='bandeja' ? /bandeja|inbox|convers/i.test(p) : /historial|mensaje|chat|convers/i.test(p));
        return [...keys, ...fallback].map(p=>base+p);
      }
    } catch(e) {}
    return fallback.map(p=>base+p);
  }
  async function postJson(url, payload){
    const r = await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    let body = null; try { body = await r.json(); } catch(e) {}
    return { ok:r.ok, status:r.status, body };
  }

  function payloadBackend(kind, payload){
    const perfil = payload.perfil || payload.perfil_nombre || 'Diego';
    if (kind === 'bandeja') {
      const chats = payload.chats || payload.conversaciones || [];
      return {
        perfil,
        conversaciones: chats.map((c, i) => ({
          orden_bandeja: c.orden_bandeja || i + 1,
          cliente: c.cliente || `Chat ${i+1}`,
          producto: c.producto || c.producto_nombre || 'Producto sin identificar',
          mensaje: c.mensaje || c.ultimo_mensaje || '',
          precio: c.precio || '',
          enlace_chat: c.enlace_chat || '',
          facebook_chat_id: c.facebook_chat_id || '',
          tiempo_messenger: c.tiempo_messenger || ''
        }))
      };
    }
    const chat = payload.chat || getCurrentChatInfo();
    const mensajes = payload.mensajes || [];
    const titulo = chat.titulo || '';
    let cliente = titulo.split('·')[0].trim() || 'Cliente sin identificar';
    let producto = titulo.includes('·') ? titulo.split('·').slice(1).join('·').trim() : 'Producto sin identificar';
    if (/messenger\s*\|\s*facebook|facebook$/i.test(cliente)) cliente = 'Cliente sin identificar';
    if (/messenger\s*\|\s*facebook/i.test(producto)) producto = 'Producto sin identificar';
    const ultimo = mensajes.length ? (mensajes[mensajes.length-1].contenido || mensajes[mensajes.length-1].texto || '') : '';
    return {
      perfil,
      cliente,
      producto,
      mensaje: ultimo,
      precio: '',
      enlace_chat: chat.enlace_chat || location.href,
      facebook_chat_id: chat.facebook_chat_id || ((location.href.match(/\/messages\/t\/([^/?#]+)/)||[])[1] || ''),
      tiempo_messenger: '',
      modo_captura: 'historial',
      historial: mensajes.map((m,i)=>({
        remitente: m.remitente || 'cliente',
        contenido: m.contenido || m.texto || '',
        fecha: m.fecha || m.fecha_original || '',
        orden_chat: m.orden_chat || i+1
      })).filter(m=>m.contenido)
    };
  }

  async function sync(kind, payload){
    const s = await cfg();
    const base=(s.backendBase||'http://127.0.0.1:8000').replace(/\/$/,'');
    const url = kind === 'bandeja' ? base + '/api/sincronizar_bandeja' : base + '/api/nuevo_mensaje';
    const finalPayload = payloadBackend(kind, payload);
    const res = await postJson(url, finalPayload);
    if (res.ok) { log(`Sync ${kind} OK -> ${url}`); return true; }
    throw new Error(`Backend rechazó sync ${kind}: ${url} ${res.status} ${JSON.stringify(res.body||{})}`);
  }



  function currentPerfilNombre(){
    const href = location.href;
    if (/127\.0\.0\.1:8000|localhost:8000/.test(href)) {
      const h = norm(document.querySelector('h1')?.innerText || '');
      const m = h.match(/Bandeja de\s+(.+)/i);
      if (m) return m[1].trim();
    }
    return 'Diego';
  }

  async function createCrmAction(conversacionId, accion='abrir_chat'){
    const s = await cfg();
    const base=(s.backendBase||'http://127.0.0.1:8000').replace(/\/$/,'');
    const payload = { conversacion_id:Number(conversacionId), accion, perfil_id:Number(s.perfilId||1) };
    const r = await fetch(base+'/api/crear_accion_extension', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
    return r.ok;
  }

  function installCrmClickBridge(){
    if (!/127\.0\.0\.1:8000|localhost:8000/.test(location.href)) return;
    if (window.__MH_CRM_CLICK_BRIDGE_3B13__) return;
    window.__MH_CRM_CLICK_BRIDGE_3B13__ = true;
    document.addEventListener('click', async (ev)=>{
      const a = ev.target.closest && ev.target.closest('a.chat-list-item[data-conversacion-id]');
      if (!a) return;
      const id = a.getAttribute('data-conversacion-id');
      if (!id) return;
      status('Orden enviada a la extensión: abrir chat CRM #' + id);
      createCrmAction(id, 'abrir_chat').catch(()=>{});
    }, true);
  }

  let lastActionId = 0;
  async function pollCrmActions(){
    try{
      const s = await cfg(); if (!s.enabled || !isFacebook() || !isMessages()) return;
      const base=(s.backendBase||'http://127.0.0.1:8000').replace(/\/$/,'');
      const perfil = encodeURIComponent(s.perfilNombre || 'Diego');
      const j = await fetch(base+'/api/acciones_extension?perfil='+perfil).then(r=>r.ok?r.json():null).catch(()=>null);
      const action = j && j.acciones && j.acciones[0];
      if (!action || action.accion_id === lastActionId) return;
      lastActionId = action.accion_id;
      await processCrmAction(action, base);
    }catch(e){ console.warn('[MH 3B.13] poll acciones error', e); }
  }

  async function processCrmAction(action, base){
    try{
      log('Acción CRM recibida:', action.accion, action.cliente || '', action.facebook_chat_id || action.enlace_chat || '');
      const okDrawer = await openMarketplaceDrawerStrict();
      if (!okDrawer) throw new Error('No pude validar cajón Marketplace para ejecutar acción CRM');
      await sleep(800);

      if (action.accion === 'cargar_mas_conversaciones') {
        const chats = await captureInboxWithScroll(8);
        await sync('bandeja', { perfil_id: (await cfg()).perfilId||1, chats, fuente:'cargar_mas_3B13' });
        await postJson(base+'/api/marcar_accion_extension', { accion_id: action.accion_id, ok:true, error:'' });
        log('Cargar más conversaciones completado:', chats.length);
        return;
      }

      const link = await findConversationWithScroll(action, 26);
      if (!link) throw new Error('No encontré ese chat en el cajón Marketplace después de buscar con scroll.');
      await humanClick(link, 'chat solicitado desde CRM');
      await sleep(2800);
      const mensajes = captureCurrentChatHistory();
      await sync('historial', { perfil_id: (await cfg()).perfilId||1, chat:getCurrentChatInfo(), mensajes, fuente:'accion_crm_3B13' });
      await postJson(base+'/api/marcar_accion_extension', { accion_id: action.accion_id, ok:true, error:'' });
      log('Chat CRM abierto y capturado:', mensajes.length, 'mensajes');
    }catch(e){
      await postJson(base+'/api/marcar_accion_extension', { accion_id: action.accion_id, ok:false, error:String(e.message||e) }).catch(()=>{});
      err('Acción CRM falló:', e.message || e);
    }
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'MH_STATE_CHANGED' && msg.enabled) setTimeout(runFull, 1000);
    if (msg?.type === 'MH_RUN_NOW') runFull();
    if (msg?.type === 'MH_CAPTURE_BANDEJA') (async()=>{try{await openMarketplaceDrawerStrict(); const s=await cfg(); const chats=captureMarketplaceInbox(); await sync('bandeja',{perfil_id:s.perfilId||1,chats,fuente:'manual_3B13'}); log('Bandeja enviada: '+chats.length);}catch(e){err(e.message)}})();
    if (msg?.type === 'MH_CAPTURE_HISTORIAL') (async()=>{try{const s=await cfg(); const mensajes=captureCurrentChatHistory(); await sync('historial',{perfil_id:s.perfilId||1,chat:getCurrentChatInfo(),mensajes,fuente:'manual_3B13'}); log('Historial enviado: '+mensajes.length);}catch(e){err(e.message)}})();
  });

  (async function boot(){
    await injectCrmBanner();
    installCrmClickBridge();
    const s = await cfg();
    if (s.enabled && isFacebook() && !startedOnce) { startedOnce=true; setTimeout(runFull, 1200); }
    setInterval(()=>{ injectCrmBanner(); installCrmClickBridge(); }, 2500);
    setInterval(pollCrmActions, 3000);
  })();
})();
